from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date, timedelta
from sqlalchemy import func
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'biology-study-local-change-me')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE, 'instance', 'biology.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
os.makedirs(os.path.join(BASE, 'instance'), exist_ok=True)
db = SQLAlchemy(app)

class Page(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    grade=db.Column(db.String(20), nullable=False)
    chapter=db.Column(db.String(200), nullable=False, default='متن کتاب')
    page_no=db.Column(db.String(30), nullable=False)
    title=db.Column(db.String(250), default='')
    content=db.Column(db.Text, default='')
    summary=db.Column(db.Text, default='')
    order_no=db.Column(db.Integer, default=0)
    questions=db.relationship('Question', backref='page', cascade='all, delete-orphan')
class Progress(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    page_id=db.Column(db.Integer, db.ForeignKey('page.id'), unique=True)
    status=db.Column(db.String(20), default='unread')
    percent=db.Column(db.Integer, default=0)
    last_position=db.Column(db.Integer, default=0)
    updated_at=db.Column(db.DateTime, default=datetime.utcnow)
    page=db.relationship('Page')
class StudySession(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    started_at=db.Column(db.DateTime, default=datetime.utcnow)
    seconds=db.Column(db.Integer, default=0)
    page_id=db.Column(db.Integer, db.ForeignKey('page.id'), nullable=True)
class Question(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    page_id=db.Column(db.Integer, db.ForeignKey('page.id'), nullable=False)
    prompt=db.Column(db.Text, nullable=False)
    a=db.Column(db.Text, nullable=False); b=db.Column(db.Text, nullable=False); c=db.Column(db.Text, nullable=False); d=db.Column(db.Text, nullable=False)
    answer=db.Column(db.String(1), nullable=False)
    explanation=db.Column(db.Text, default=''); source=db.Column(db.String(200), default='')
class Review(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    page_id=db.Column(db.Integer, db.ForeignKey('page.id'), nullable=False)
    due_date=db.Column(db.Date, nullable=False)
    interval_days=db.Column(db.Integer, default=1)
    ease=db.Column(db.Float, default=2.5)
    repetitions=db.Column(db.Integer, default=0)
    page=db.relationship('Page')

with app.app_context():
    db.create_all()
    # Seed all 424 PDF pages once. Original PDF remains available for diagrams and figures.
    if Page.query.count() == 0:
        path=os.path.join(BASE,'static','textbook_pages.json')
        if os.path.exists(path):
            with open(path,encoding='utf-8') as f: data=json.load(f)
            for item in data.get('pages',[]):
                db.session.add(Page(grade=item['grade'], chapter=item.get('chapter','متن کتاب'), page_no=item['page_no'],
                    title=item.get('title',''), content=item.get('content',''), summary='', order_no=item['order_no']))
            db.session.commit()

def get_next(page):
    return Page.query.filter(Page.order_no>page.order_no).order_by(Page.order_no).first()

@app.route('/')
def home():
    total=Page.query.count(); done=Progress.query.filter_by(status='done').count()
    due=Review.query.filter(Review.due_date<=date.today()).count()
    seconds=db.session.query(func.coalesce(func.sum(StudySession.seconds),0)).scalar()
    resume=Progress.query.filter(Progress.status.in_(['learning','done'])).order_by(Progress.updated_at.desc()).first()
    return render_template('home.html',total=total,done=done,due=due,seconds=seconds,resume=resume)

@app.route('/library')
def library():
    grade=request.args.get('grade','')
    q=request.args.get('q','').strip()
    query=Page.query
    if grade: query=query.filter_by(grade=grade)
    if q: query=query.filter((Page.content.contains(q)) | (Page.title.contains(q)) | (Page.page_no.contains(q)))
    pages=query.order_by(Page.order_no).limit(500).all()
    progress={p.page_id:p for p in Progress.query.all()}
    return render_template('library.html',pages=pages,progress=progress,grade=grade,q=q)

@app.route('/study/<int:page_id>')
def study(page_id):
    page=Page.query.get_or_404(page_id)
    prog=Progress.query.filter_by(page_id=page.id).first()
    if not prog:
        prog=Progress(page_id=page.id,status='learning'); db.session.add(prog)
    else: prog.status='learning'; prog.updated_at=datetime.utcnow()
    db.session.commit()
    prev=Page.query.filter(Page.order_no<page.order_no).order_by(Page.order_no.desc()).limit(3).all()
    nxt=get_next(page)
    return render_template('study.html',page=page,prog=prog,previous=prev,reviews=[],next_id=nxt.id if nxt else None)

@app.post('/api/progress/<int:page_id>')
def save_progress(page_id):
    data=request.get_json(force=True); p=Progress.query.filter_by(page_id=page_id).first() or Progress(page_id=page_id)
    p.percent=max(0,min(100,int(data.get('percent',0)))); p.last_position=max(0,int(data.get('position',0)))
    p.status='done' if p.percent>=98 else 'learning'; p.updated_at=datetime.utcnow()
    db.session.add(p); db.session.commit(); return jsonify(ok=True)

@app.post('/api/session')
def save_session():
    data=request.get_json(force=True); seconds=max(0,min(86400,int(data.get('seconds',0))))
    if seconds: db.session.add(StudySession(seconds=seconds,page_id=data.get('page_id'))); db.session.commit()
    return jsonify(ok=True)

@app.post('/question/<int:qid>/answer')
def answer(qid):
    q=Question.query.get_or_404(qid); chosen=request.form.get('choice','')
    flash(('درست است ✅' if chosen==q.answer else 'نادرست است ❌ پاسخ صحیح: '+q.answer.upper()),'success' if chosen==q.answer else 'error')
    return redirect(url_for('study',page_id=q.page_id)+'#q'+str(qid))

@app.post('/review/<int:page_id>')
def schedule_review(page_id):
    rating=request.form.get('rating','again'); r=Review.query.filter_by(page_id=page_id).order_by(Review.due_date.desc()).first()
    if not r: r=Review(page_id=page_id,due_date=date.today(),interval_days=1)
    if rating=='easy': r.interval_days=max(3,int(r.interval_days*max(r.ease,2.5))); r.ease=min(3.0,r.ease+0.15); r.repetitions+=1
    elif rating=='good': r.interval_days=max(2,r.interval_days*2); r.repetitions+=1
    else: r.interval_days=1; r.repetitions=0; r.ease=max(1.3,r.ease-0.2)
    r.due_date=date.today()+timedelta(days=r.interval_days); db.session.add(r); db.session.commit()
    flash('مرور بعدی زمان‌بندی شد.','success'); return redirect(url_for('study',page_id=page_id))

@app.route('/reviews')
def reviews():
    items=Review.query.filter(Review.due_date<=date.today()).order_by(Review.due_date).all()
    return render_template('reviews.html',items=items)
@app.route('/stats')
def stats():
    pages=Page.query.count(); done=Progress.query.filter_by(status='done').count()
    total_seconds=db.session.query(func.coalesce(func.sum(StudySession.seconds),0)).scalar()
    sessions=StudySession.query.count()
    return render_template('stats.html',pages=pages,done=done,total_seconds=total_seconds,sessions=sessions)
@app.route('/book-pdf')
def book_pdf():
    return send_from_directory(os.path.join(BASE,'static'),'کتابهای_زیست_دهم_یازدهم_دوازدهم.pdf',as_attachment=False)

if __name__=='__main__':
    app.run(host='127.0.0.1',port=5000,debug=False)
